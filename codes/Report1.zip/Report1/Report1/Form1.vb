﻿Option Explicit Off
Public Class Form1

    Private Sub Label1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles student_id.Click

    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        student_id.Text = "634272104"
        student_name.Text = "chanakan"
        student_email.Text = "chanakan@gmail.com"

        Dim birthdate As Date = #13/8/1999#
        Dim age As Integer

        age = Year(Today()) - Year(Birthdate)

        student_age.Text = age.ToString & "เกิดวัน " & Birthdate.ToString("dddd")

        student_enroll.Text = (16000 * 8).ToString("&#,###")
    End Sub
End Class