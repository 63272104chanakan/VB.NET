﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.price = New System.Windows.Forms.TextBox()
        Me.interset = New System.Windows.Forms.TextBox()
        Me.year1 = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.detal = New System.Windows.Forms.RichTextBox()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.dow = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(21, 30)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(43, 13)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "ราคารถ"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(22, 96)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(70, 13)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "อัตราดอกเบี้ย"
        '
        'price
        '
        Me.price.Location = New System.Drawing.Point(24, 62)
        Me.price.Name = "price"
        Me.price.Size = New System.Drawing.Size(100, 20)
        Me.price.TabIndex = 2
        '
        'interset
        '
        Me.interset.Location = New System.Drawing.Point(24, 112)
        Me.interset.Name = "interset"
        Me.interset.Size = New System.Drawing.Size(100, 20)
        Me.interset.TabIndex = 3
        '
        'year1
        '
        Me.year1.Location = New System.Drawing.Point(153, 112)
        Me.year1.Name = "year1"
        Me.year1.Size = New System.Drawing.Size(100, 20)
        Me.year1.TabIndex = 5
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(150, 96)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(47, 13)
        Me.Label3.TabIndex = 4
        Me.Label3.Text = "จำนวนปี"
        '
        'detal
        '
        Me.detal.Location = New System.Drawing.Point(12, 191)
        Me.detal.Name = "detal"
        Me.detal.Size = New System.Drawing.Size(241, 111)
        Me.detal.TabIndex = 6
        Me.detal.Text = ""
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(75, 149)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(132, 36)
        Me.Button1.TabIndex = 7
        Me.Button1.Text = "คำนวนดอกเบี้ยเช่าซื้อ"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'dow
        '
        Me.dow.Location = New System.Drawing.Point(153, 62)
        Me.dow.Name = "dow"
        Me.dow.Size = New System.Drawing.Size(100, 20)
        Me.dow.TabIndex = 9
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(150, 46)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(84, 13)
        Me.Label4.TabIndex = 8
        Me.Label4.Text = "จำนวนเงินดาวน์"
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(284, 312)
        Me.Controls.Add(Me.dow)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.detal)
        Me.Controls.Add(Me.year1)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.interset)
        Me.Controls.Add(Me.price)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Name = "Form1"
        Me.Text = "การผ่อนชำระค่าเช่าซื้อ"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents price As System.Windows.Forms.TextBox
    Friend WithEvents interset As System.Windows.Forms.TextBox
    Friend WithEvents year1 As System.Windows.Forms.TextBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents detal As System.Windows.Forms.RichTextBox
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents dow As System.Windows.Forms.TextBox
    Friend WithEvents Label4 As System.Windows.Forms.Label

End Class
