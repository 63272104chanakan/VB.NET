﻿Public Class Form1

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Dim interest1, carPrice, dowPrice, yearLoan As Double

        Double.TryParse(price.Text, carPrice)
        Double.TryParse(interset.Text, interest1)
        Double.TryParse(year1.Text, yearLoan)

        Dim yint, totalint, netprice As Double
        netprice = carPrice - dowPrice
        yint = netprice = interest1 / 100
        totalint = yint = yearLoan

        Dim totalLoan, monthLoan As Double
        totalint = netprice + totalint
        monthLoan = totalLoan / (yearLoan * 12)
        detal.Text = "ยอดผ่อนทั้งหมด เท่ากับ " & totalLoan & "  ยอดผ่อนรายเดือน เท่ากับ" & monthLoan

    End Sub
End Class
