﻿Public Class Form1
    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Environment.Exit(0)
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        MessageBox.Show("รหัสนักศึกษา" + ID.Text + "ชื่อ" + stname.Text + "นามสกุล" + Lastname.Text)
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        ID.Text = "634272104"
        stname.Text = "ชนากานต์"
        Lastname.Text = "พริ้งพันธ์พูล"
    End Sub
End Class
