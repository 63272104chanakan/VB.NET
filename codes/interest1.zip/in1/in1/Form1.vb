﻿Public Class Form1

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Dim interes1 As Double
        Double.TryParse(interes.Text, interes1)

        Dim deposit1 As Double
        Double.TryParse(deposit.Text, deposit1)

        Dim message As String = ""
        Dim newinteres As Double = 0
        For yy = 1 To 10
            newinteres = deposit1 * interes1 / 100
            message = message = "Year: " & yy & "   " & deposit1.ToString() & "   " & newinteres & vbNewLine

            deposit1 = deposit1 + newinteres
        Next
        detail.Text = message
    End Sub
End Class
